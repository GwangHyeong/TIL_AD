package com.example.myboardtest7;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;

public class CommentDetail extends AppCompatActivity implements View.OnClickListener {
    String key_id;

    CommentDAO commentDAO = new CommentDAO(this);
    CommentDTO commentDTO;
    ListActivity main;



    private Context mContext2;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.comment_list);

        Button cbtnHome = (Button)this.findViewById(R.id.cbtnHome);
        cbtnHome.setOnClickListener(this); //btnHome 버튼리스너

        //인텐트로준 값받아오기
        Intent intent = getIntent();
        key_id = intent.getExtras().getString("key_id");
        Log.e("testBoardDetial", String.valueOf(key_id));

        mContext2 = this.getApplicationContext();
        ListView clistView = (ListView)this.findViewById(R.id.clistView);
        CommentDAO dao = new CommentDAO(this);
        final ArrayList<CommentDTO> arList2 = dao.getArrayList(key_id);
        CommentAdapter adapter = new CommentAdapter(this,arList2);
        clistView.setAdapter(adapter); //listView에 어댑터 붙이기

        String testa = String.valueOf(arList2);
        Log.e("testDTO", String.valueOf(testa));

    }



    @Override
    public void onClick(View v) {
        Intent intent;
        switch (v.getId()){
            case R.id.cbtnHome:
                intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                finish();
        }
    }
}