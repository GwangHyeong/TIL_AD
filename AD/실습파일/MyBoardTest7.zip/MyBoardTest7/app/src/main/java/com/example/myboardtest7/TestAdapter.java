package com.example.myboardtest7;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class TestAdapter extends BaseAdapter {
    Activity context;
    ArrayList<TestDTO> arList;
    LayoutInflater mInflater;
    OnBoardItemClickListener listener;

    TestAdapter(Activity context, ArrayList<TestDTO> arList){
        this.context=context;
        this.arList=arList;

        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    /**
     * Method to set item list and notify adapter to update its views.
     *
     * @param list
     */
    public void setItemlist(ArrayList<TestDTO> list){
        if(list != null){
            arList = list;
            notifyDataSetChanged();
        }
    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent){
        View row = mInflater.inflate(R.layout.activity_list_listitem,parent,false);

        String p_id = arList.get(position).getP_id();
        String title = arList.get(position).getTitle();
        String name = arList.get(position).getName();
        String pcontent = arList.get(position).getPcontent();
        String pregdate = arList.get(position).getPregdate();


        TextView txtTitle = ((TextView) row.findViewById(R.id.txtTitle));
        TextView txtName = ((TextView) row.findViewById(R.id.txtName));
        TextView txtPcontent = ((TextView) row.findViewById(R.id.txtPcontent));
        TextView txtPregdate = ((TextView) row.findViewById(R.id.txtPregdate));


        txtTitle.setText(title);
        txtName.setText(name);
        txtPcontent.setText(pcontent);
        txtPregdate.setText(pregdate);

        Log.e("test", String.valueOf(position));

        return row;
    }

    @Override
    public int getCount() {
        if (arList != null) {
            return arList.size();
        } else {
            return 0;
        }
    }
    @Override
    public Object getItem(int position) {
        TestDTO item = null;
        if (arList != null && arList.size() > 0) {
            item = arList.get(position);
        }
        return item;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public boolean isEnabled(int position){
        return true;
    }

    @Override
    public int getItemViewType(int position){
        return super.getItemViewType(position);
    }

    @Override
    public int getViewTypeCount(){
        return super.getViewTypeCount();
    }

    /**
     * Method to set the listener class object.
     *
     * @param listener
     */
    public void setOnBoardClickListener(OnBoardItemClickListener listener) {
        this.listener = listener;
    }

    /**
     * Interface to provide click events to the required classes.
     *
     * @author Amruta.Doye
     *
     */
    public interface OnBoardItemClickListener {

        /**
         * The method declaration for user selected. This method will be fired
         * when user click on check/uncheck the checkbox on the list item.
         *
         * @param position
         * @param item
         */
    }
}
