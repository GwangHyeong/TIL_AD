package com.example.myboardtest7;

public class TestDTO {
    int _id;
    String p_id;
    String title;
    String name;
    String pcontent;
    String pregdate;

    public TestDTO() {}

    public TestDTO(String p_id, String title, String name, String pcontent){
        this.p_id = p_id;
        this.title = title;
        this.name = name;
        this.pcontent = pcontent;
    }
    public TestDTO(int _id, String p_id,String title, String name, String pcontent, String pregdate){
        this._id = _id;
        this.p_id = p_id;
        this.title = title;
        this.name = name;
        this.pcontent = pcontent;
        this.pregdate = pregdate;
    }
    public TestDTO(String title, String name, String pcontent){
        this.title = title;
        this.name = name;
        this.pcontent = pcontent;
    }

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }


    public String getP_id() {
        return p_id;
    }

    public void setP_id(String p_id) {
        this.p_id = p_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPcontent() {
        return pcontent;
    }

    public void setPcontent(String pcontent) {
        this.pcontent = pcontent;
    }

    public String getPregdate() {
        return pregdate;
    }

    public void setPregdate(String pregdate) {
        this.pregdate = pregdate;
    }


}
