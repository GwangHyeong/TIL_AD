package com.example.myboardtest7;

public class CommentDTO {
    int _id;
    String b_date;
    String writer;
    String bcontent;
    String bregdate;

    public CommentDTO(){}

    //댓글작성
    public CommentDTO(String writer,String bcontent, String b_date){
        this.writer = writer;
        this.bcontent = bcontent;
        this.b_date = b_date;
    }
    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public String getB_date() {
        return b_date;
    }

    public void setB_date(String b_date) {
        this.b_date = b_date;
    }

    public String getWriter() {
        return writer;
    }

    public void setWriter(String writer) {
        this.writer = writer;
    }

    public String getBcontent() {
        return bcontent;
    }

    public void setBcontent(String bcontent) {
        this.bcontent = bcontent;
    }

    public String getBregdate() {
        return bregdate;
    }

    public void setBregdate(String bregdate) {
        this.bregdate = bregdate;
    }


}
