package com.example.myboardtest7;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class BoardDetail extends AppCompatActivity implements View.OnClickListener{
    String key_id;

    TestDAO testDAO = new TestDAO(this);
    TestDTO testDTO;
    CommentDAO commentDAO = new CommentDAO(this);
    CommentDTO commentDTO;
    ListActivity main;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.board_detail);

        Button btnAll = (Button) this.findViewById(R.id.btnAll);
        btnAll.setOnClickListener(this);
        Button btnComment = (Button) this.findViewById(R.id.btnComment);
        btnComment.setOnClickListener(this);
        Button btnCommnet_detail = (Button)this.findViewById(R.id.btnComment_detail);
        btnCommnet_detail.setOnClickListener(this);

        //인텐트로준 값받아오기
        Intent intent = getIntent();
        key_id = intent.getExtras().getString("key_id");
        Log.e("testBoardDetial", String.valueOf(key_id));

        commentDTO = commentDAO.getRecord(key_id);
        testDTO = testDAO.getRecord(key_id);

       TextView tvTitle = (TextView) findViewById(R.id.tvTitle);
       TextView tvName = (TextView) findViewById(R.id.tvName);
       TextView tvPcontent = (TextView) findViewById(R.id.tvPcontent);


        tvTitle.setText(testDTO.getTitle());
        String testa = testDTO.getTitle();
        Log.e("testDTO", String.valueOf(testa));
        tvName.setText(testDTO.getName());
        tvPcontent.setText(testDTO.getPcontent());


    }

    @Override
    public void onClick(View v) {

        Intent intent = null;

        switch (v.getId()) {
            case R.id.btnComment:
                intent = new Intent(this, CommentInsert.class);
                intent.putExtra("key_id",key_id); //값 전달하기.
                Log.e("BoardDetail",key_id + "값 전달확인");
                startActivity(intent);
                break;

            case R.id.btnComment_detail:
                intent = new Intent(this, CommentDetail.class);
                intent.putExtra("key_id",key_id); //값 전달하기.
                Log.e("BoardDetail",key_id + "값 전달확인");
                startActivity(intent);
                break;

            case R.id.btnAll:
                intent = new Intent(this, ListActivity.class);
                startActivity(intent);
                break;

        }
    }
}
