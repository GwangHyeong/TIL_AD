package com.example.myboardtest7;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class CommentAdapter extends BaseAdapter {
    Activity context;
    ArrayList<CommentDTO> arList2;
    LayoutInflater mInflater;

    CommentAdapter(Activity context, ArrayList<CommentDTO> arList2) {
        this.context = context;
        this.arList2 = arList2;

        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View row = mInflater.inflate(R.layout.comment_list_listitem, parent, false);


        String writer = arList2.get(position).getWriter();
        String bcontent = arList2.get(position).getBcontent();
        String bregdate = arList2.get(position).getBregdate();


        TextView ctxt_writer = ((TextView) row.findViewById(R.id.ctxt_writer));
        TextView ctxt_bcontent = ((TextView) row.findViewById(R.id.ctxt_bcontent));
        TextView ctxt_bregdate = ((TextView) row.findViewById(R.id.ctxt_bregdate));


        ctxt_writer.setText(writer);
        ctxt_bcontent.setText(bcontent);
        ctxt_bregdate.setText(bregdate);

        return row;
    }

    @Override
    public int getCount() {
        return arList2.size();
    }

    @Override
    public Object getItem(int position) {
        return arList2.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public boolean isEnabled(int position){
        return true;
    }

    @Override
    public int getItemViewType(int position){
        return super.getItemViewType(position);
    }

    @Override
    public int getViewTypeCount(){
        return super.getViewTypeCount();
    }
}
