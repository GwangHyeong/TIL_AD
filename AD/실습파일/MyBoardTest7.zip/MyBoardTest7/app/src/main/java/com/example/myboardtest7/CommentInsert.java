package com.example.myboardtest7;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class CommentInsert extends AppCompatActivity implements View.OnClickListener {

    String key_id;
    EditText editWriter;
    EditText editCcontent;
    TextView txtBdate;

    @Override
    protected void onCreate(Bundle saveInstanceState){
        super.onCreate(saveInstanceState);
        setContentView(R.layout.comment_insert);

        editWriter = (EditText)findViewById(R.id.editWriter);
        editCcontent = (EditText)findViewById(R.id.editCcontent);
        txtBdate = (TextView)findViewById(R.id.txtBdate);

        Intent intent = getIntent();
        key_id = intent.getExtras().getString("key_id");
        Log.e("CommentInsert", String.valueOf(key_id));

        txtBdate.setText(key_id);
        txtBdate.setVisibility(View.INVISIBLE);

        Button btnCompletComment = (Button)this.findViewById(R.id.btnCompletComment);
        btnCompletComment.setOnClickListener(this);


    }


    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btnCompletComment:
                CommentDTO dto = new CommentDTO();
                dto.setWriter(editWriter.getText().toString());
                dto.setBcontent(editCcontent.getText().toString());
                dto.setB_date(txtBdate.getText().toString());

                Log.e("CommentInsert", String.valueOf(dto));

                CommentDAO dao = new CommentDAO(this);
                int n = dao.commentinsert(dto);
                if(n>0){
                    Log.e("CommentInsert",n + " 번째 저장되었습니다.");
                }
                else{
                    Log.e("Comment Insert", "저장 실패했습니다.");
                }
                finish();
                break;
        }
    }
}
