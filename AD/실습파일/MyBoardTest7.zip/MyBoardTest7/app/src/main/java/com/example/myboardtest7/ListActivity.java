package com.example.myboardtest7;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;


public class ListActivity extends AppCompatActivity implements View.OnClickListener {

//    ListView listView = null;
//    ArrayList<TestDTO> arList;
//    String m_id = null;
//    //TestDAO testDAO = new TestDAO(getContext());
//    TestDAO testDAO = new TestDAO(this);
    private Context mContext;
//    TestAdapter testAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

       Button btnHome = (Button)this.findViewById(R.id.btnHome);
       btnHome.setOnClickListener(this); //btnHome 버튼리스너
//
//        mContext = this.getApplicationContext();
//        testDAO = new TestDAO(mContext);
//        arList = testDAO.getArrayList();


        mContext = this.getApplicationContext();
        ListView listView = (ListView)this.findViewById(R.id.listView);
        TestDAO dao = new TestDAO(this);
        final ArrayList<TestDTO> arList = dao.getArrayList();
        TestAdapter adapter = new TestAdapter(this,arList);
        listView.setAdapter(adapter); //listView에 어댑터 붙이기

        String testa = String.valueOf(arList);
        Log.e("testDTO", String.valueOf(testa));

        //리스트뷰 아이템클릭리스너.
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                if(position >= 0){
                    Toast.makeText(getApplicationContext(),arList.get(position).get_id() + " 자세히 보기", Toast.LENGTH_SHORT).show();
                    Log.e("ListenerTest","L_TEST"+position);


                    Intent intent = new Intent(ListActivity.this,BoardDetail.class);
                    //Error 드디어찾은곳. Integer을 형변환 하지않고 String 에 뿌려서 그런듯;?
                    intent.putExtra("key_id",String.valueOf(arList.get(position).get_id())); //값 전달하기.

                    //값잘넘겻는지 로그캣 확인
                    int listentest = arList.get(position).get_id();
                    Log.e("ListenerTest", String.valueOf(listentest));
                    startActivity(intent);
                     }
            }
        });
    }



    @Override
    public void onClick(View v) {
        Intent intent;
        switch (v.getId()){
            case R.id.btnHome:
                intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                finish();
        }
    }
}
