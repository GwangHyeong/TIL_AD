package com.example.myboardtest7;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class MainDBHelper extends SQLiteOpenHelper {
    private Context context;

    // 자료형 선언
    MainDBHelper dbHelper = null;
    SQLiteDatabase db = null;

    // DB 버전(DB가 변경될 때마다 버전을 변경해주어야 함)
    private static final int DB_VERSION = 10;

    // DB명, 테이블명 상수 정의
    private static final String DB = "TEST.db";
    private static final String TestTable = "posttbl";
    private static final String CommentTable = "bodtbl";

    public MainDBHelper(Context context){
        super(context,DB,null,DB_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        String sql = "";

        //create posttbl
        try{
            sql = "CREATE TABLE '" + TestTable + "' ("
                    + " '_id' INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + " 'p_id' TEXT UNIQUE,"
                    + " 'title' TEXT NOT NULL,"
                    + " 'name' TEXT NOT NULL,"
                    + " 'pcontent' TEXT NOT NULL,"
                    + " 'pregdate' TEXT DEFAULT CURRENT_TIMESTAMP "
                    + ");";
            db.execSQL(sql);
        } catch (Exception e){
            e.printStackTrace();
        }
        //create table end



        //create bodtbl
        try{
            sql = "CREATE TABLE '" + CommentTable + "' ("
                    + " '_id' INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + " 'b_date' TEXT,"
                    + " 'writer' TEXT NOT NULL,"
                    + " 'bcontent' TEXT NOT NULL,"
                    + " 'bregdate' TEXT DEFAULT CURRENT_TIMESTAMP"
                 //   + " FOREIGN KEY('b_date') REFERENCES 'posttbl'('_id') ON DELETE SET NULL ON UPDATE CASCADE"
                    + ");";
            db.execSQL(sql);
            Log.e("MainDBHelper",sql);
        } catch (Exception e){
            e.printStackTrace();
        }
        //create table end
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        Log.e("MYTAG", "Upgrading database from version " + oldVersion + "to" +newVersion + ".");
    }


}
