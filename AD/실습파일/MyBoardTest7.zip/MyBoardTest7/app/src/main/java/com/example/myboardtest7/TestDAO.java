package com.example.myboardtest7;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;

import java.util.ArrayList;

public class TestDAO {
    private String tableName = "posttbl";

    private Context m_context;

    public TestDAO(Context context){
        this.m_context = context;
    }
    public SQLiteDatabase getConn() {
        MainDBHelper dbHelper = new MainDBHelper(m_context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        return db;
    }

    public int insert(TestDTO dto){
        SQLiteDatabase conn = null;
        ContentValues recordValues = new ContentValues();
        recordValues.put("p_id",dto.getP_id());
        recordValues.put("title",dto.getTitle());
        recordValues.put("name",dto.getName());
        recordValues.put("pcontent",dto.getPcontent());

        SQLiteDatabase db = getConn();
        int rowPosition = 0;
        try{
            rowPosition = (int) db.insert(tableName, null, recordValues);
            Log.e("MYTAG",rowPosition + " inserted");
        }catch (SQLiteException e){
            e.printStackTrace();
        }
        db.close();

        return rowPosition;
    }
    //리스트
    public ArrayList<TestDTO> getArrayList() {
        ArrayList<TestDTO> arList = new ArrayList<TestDTO>();
        SQLiteDatabase db = getConn();
        String sql;
        Cursor cursor;

        //목록보여줄 SQL문
        sql = "SELECT * FROM '" + tableName + "' ORDER BY '_ID' DESC ;";

        Log.v("MYTAG" , sql);
        cursor = db.rawQuery(sql, null);

        while(cursor.moveToNext()){
            TestDTO dto = new TestDTO();
            dto.set_id(cursor.getInt(cursor.getColumnIndexOrThrow("_id")));
            dto.setP_id(cursor.getString(cursor.getColumnIndexOrThrow("p_id")));
            dto.setTitle(cursor.getString(cursor.getColumnIndexOrThrow("title")));
            dto.setName(cursor.getString(cursor.getColumnIndexOrThrow("name")));
            dto.setPcontent(cursor.getString(cursor.getColumnIndexOrThrow("pcontent")));
            dto.setPregdate(cursor.getString(cursor.getColumnIndexOrThrow("pregdate")));

            Log.e("MYTAG",dto.toString());
            arList.add(dto);

        }
        cursor.close();


        return arList;
    }
    public TestDTO getRecord(String key_id){ //String _id 안되면 고치기 *******
        TestDTO dto = new TestDTO();
        SQLiteDatabase db = getConn();
        String sql;
        Cursor cursor;
        sql =  "SELECT * FROM " + tableName + " WHERE _id='" + key_id + "';";
        Log.e("MYTAG2" , sql);
        try{
            SQLiteDatabase conn = getConn();
            cursor = conn.rawQuery(sql,null);
            while(cursor.moveToNext()){
                dto._id = cursor.getInt(cursor.getColumnIndexOrThrow("_id"));
                dto.p_id = cursor.getString(cursor.getColumnIndexOrThrow("p_id"));
                dto.title = cursor.getString(cursor.getColumnIndexOrThrow("title"));
                dto.name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                dto.pcontent = cursor.getString(cursor.getColumnIndexOrThrow("pcontent"));
                dto.pregdate = cursor.getString(cursor.getColumnIndexOrThrow("pregdate"));

                break;
            }
            cursor.close();
            conn.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        return dto;
    }
}
