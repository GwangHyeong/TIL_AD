package com.example.myboardtest7;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class InsertActivity extends AppCompatActivity implements View.OnClickListener{

    EditText editP_id;
    EditText editTitle;
    EditText editName;
    EditText editPcontent;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.board_insert);


        editTitle = (EditText)this.findViewById(R.id.editTitle);
        editName = (EditText)this.findViewById(R.id.editName);
        editPcontent = (EditText)this.findViewById(R.id.editPcontent);

        Button btnInsert = (Button)this.findViewById(R.id.btnInsert);
        btnInsert.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnInsert:
                TestDTO dto = new TestDTO();
                dto.setTitle(editTitle.getText().toString());
                dto.setName(editName.getText().toString());
                dto.setPcontent(editPcontent.getText().toString());

                TestDAO dao = new TestDAO(this);
                int n = dao.insert(dto);
                if(n>0){
                    Log.e("MYTAG", n + "번에 저장되었습니다.");
                }
                else{
                    Log.e("MYTAG","저장 실패했습니다.");
                }
                finish();
                break;
        }
    }
}
