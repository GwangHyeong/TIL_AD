package com.example.myboardtest7;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Log;

import java.util.ArrayList;

public class CommentDAO {
    private String tableName = "bodtbl";
    private Context m_context;

    public CommentDAO(Context context){
        this.m_context = context;
    }

    //디비연결
    public SQLiteDatabase getConn(){
        MainDBHelper dbHelper = new MainDBHelper(m_context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        return db;
    }

    //commentinsert
    public int commentinsert(CommentDTO dto){
        SQLiteDatabase conn = null;

        //recoordComment - ContentValues
        ContentValues recordComment = new ContentValues();
        recordComment.put("writer", dto.getWriter());
        recordComment.put("bcontent", dto.getBcontent());
        recordComment.put("b_date",dto.getB_date());

        SQLiteDatabase db = getConn();
        int rowPosition = 0;
        try{
            rowPosition = (int) db.insert(tableName, null, recordComment);
            Log.e("CommentDAO",rowPosition + " inserted(comment)");
        }catch (SQLiteException e){
            e.printStackTrace();
        }
        db.close();
        return rowPosition;
    }
    //댓글목록
    public ArrayList<CommentDTO> getArrayList() {
        ArrayList<CommentDTO> arList2 = new ArrayList<CommentDTO>();
        SQLiteDatabase db = getConn();
        String sql;
        Cursor cursor;

        //목록 sql 문
        //sql =  "SELECT * FROM " + tableName + " WHERE _id='" + key_id + "';";
        sql = "SELECT * FROM '" + tableName + "' ORDER BY '_id' DESC ;";
        Log.e("CommentDAO","sql확인" + sql);
        cursor = db.rawQuery(sql,null);
        while (cursor.moveToNext()){
            CommentDTO dto = new CommentDTO();
            dto.set_id(cursor.getInt(cursor.getColumnIndexOrThrow("_id")));
            dto.setB_date(cursor.getString(cursor.getColumnIndexOrThrow("b_date")));
            dto.setWriter(cursor.getString(cursor.getColumnIndexOrThrow("writer")));
            dto.setBcontent(cursor.getString(cursor.getColumnIndexOrThrow("bcontent")));
            dto.setBregdate(cursor.getString(cursor.getColumnIndexOrThrow("bregdate")));

            Log.e("CommentDAO",dto.toString());
            arList2.add(dto);
        }
        cursor.close();
        return arList2;
    }
    //댓글목록찐
    public ArrayList<CommentDTO> getArrayList(String key_id) {
        ArrayList<CommentDTO> arList2 = new ArrayList<CommentDTO>();
        SQLiteDatabase db = getConn();
        String sql;
        Cursor cursor;

        //목록 sql 문
        //sql =  "SELECT * FROM " + tableName + " WHERE _id='" + key_id + "';";
        sql =  "SELECT * FROM " + tableName + " WHERE b_date='" + key_id + "';";
        Log.e("CommentDAO","sql확인" + sql);
        cursor = db.rawQuery(sql,null);
        while (cursor.moveToNext()){
            CommentDTO dto = new CommentDTO();
            dto.set_id(cursor.getInt(cursor.getColumnIndexOrThrow("_id")));
            dto.setB_date(cursor.getString(cursor.getColumnIndexOrThrow("b_date")));
            dto.setWriter(cursor.getString(cursor.getColumnIndexOrThrow("writer")));
            dto.setBcontent(cursor.getString(cursor.getColumnIndexOrThrow("bcontent")));
            dto.setBregdate(cursor.getString(cursor.getColumnIndexOrThrow("bregdate")));

            Log.e("CommentDAO",dto.toString());
            arList2.add(dto);
        }
        cursor.close();
        return arList2;
    }
    public CommentDTO getRecord(String key_id){ //String _id 안되면 고치기 *******
        CommentDTO dto = new CommentDTO();
        SQLiteDatabase db = getConn();
        String sql;
        Cursor cursor;
        sql =  "SELECT * FROM " + tableName + " WHERE b_date='" + key_id + "';";
        Log.e("CommentDAO" , sql);
        try{
            SQLiteDatabase conn = getConn();
            cursor = conn.rawQuery(sql,null);
            while(cursor.moveToNext()){
                dto.set_id(cursor.getInt(cursor.getColumnIndexOrThrow("_id")));
                dto.setB_date(cursor.getString(cursor.getColumnIndexOrThrow("b_date")));
                dto.setWriter(cursor.getString(cursor.getColumnIndexOrThrow("writer")));
                dto.setBcontent(cursor.getString(cursor.getColumnIndexOrThrow("bcontent")));
                dto.setBregdate(cursor.getString(cursor.getColumnIndexOrThrow("bregdate")));
                break;
            }
            cursor.close();
            conn.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        return dto;
    }
}
