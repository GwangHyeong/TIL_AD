package com.example.myboardtest7;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;

public class CommentListActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.comment_list);
        Button cbtnHome = (Button)this.findViewById(R.id.cbtnHome);
        //cbtnHome.setOnClickListener(this);

        ListView clistView = (ListView)this.findViewById(R.id.clistView);
        CommentDAO cdao = new CommentDAO(this);
        ArrayList<CommentDTO> arList2 = cdao.getArrayList();
        CommentAdapter cadapter = new CommentAdapter(this,arList2);
        clistView.setAdapter(cadapter);
    }
    @Override
    public void onClick(View view) {
        Intent intent = null;
        switch (view.getId()){
            case R.id.cbtnHome:
                intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                finish();
                break;
        }
    }
}
