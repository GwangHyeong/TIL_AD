package com.example.list;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class MainDBHelper extends SQLiteOpenHelper {

    private Context context;

    //자료형 선언
    MainDBHelper dbHelper = null;
    SQLiteDatabase db = null;

    // DB명, 테이블명 상수 정의
    private static final String DB = "test.db";
    private static final String TestTable = "bbs";

    // DB 버전(DB가 변경될 때마다 버전을 변경해주어야 함)
    private static final int DB_VERSION = 2;

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String sql = "";

        // create bbs
        try {
            sql = "CREATE TABLE '" + TestTable + "' ("
                    + "  'num'	    INTEGER PRIMARY KEY AUTOINCREMENT"
                    + ", 'writer'	TEXT"
                    + ", 'title'	TEXT"
                    + ", 'content'	TEXT"
                    + ");";
            db.execSQL(sql);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public MainDBHelper(Context context) {
        super(context, DB, null, DB_VERSION);
        this.context = context;
    }


    // DB생성 후 연결하고 그 DB를 반환해주는 메소드
    public SQLiteDatabase getConn() {
        dbHelper = new MainDBHelper(this.context);      // db헬퍼를 생성. 무언가를 수정하면 DB 헬퍼에서 버전을 바꿔야 한다.
        db = dbHelper.getWritableDatabase();     // 쓸 수 있는 데이터베이스를 오픈.

        return db;
    }

    // DB가 업데이트 될 때 실행
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.v("MYTAG", "DB 업데이트 : 버전 " + oldVersion + "에서 버전 " + newVersion + ".");
    }
}
