package com.example.list;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteAbortException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;

public class TestDAO {

    private String tableName = "bbs";
    private Context m_context;

    public TestDAO(Context context){
        this.m_context = context;
    }

    public SQLiteDatabase getConn(){
        MainDBHelper dbHelper = new MainDBHelper(m_context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        return db;
    }
    public int insertRecord(TestDTO dto){
        ContentValues recordValues = new ContentValues();
        recordValues.put("title",dto.title);
        recordValues.put("content",dto.content);
        recordValues.put("writer",dto.writer);
        SQLiteDatabase db = getConn();
        int rowPosition = 0;
        try {
            Log.e("MYTAG", "inserted");
            rowPosition = (int) db.insert(tableName, null, recordValues);
        } catch (SQLiteAbortException e) {
            e.printStackTrace();
        }
        db.close();
        return rowPosition;
    }


//    ///목록작성
//    public ArrayList<TestDTO> getArrayList() {
//        ArrayList<TestDTO> bbsList = new ArrayList<TestDTO>();
//        SQLiteDatabase db = getConn();
//        String sql;
//        Cursor cursor;
//
//        sql = "SELECT * FROM " + tableName + " ORDER BY 'num' ASC;" ;
//        Log.e("MYTAG",sql);
//        cursor = db.rawQuery(sql, null);
//
//        while (cursor.moveToNext()) {
//            ManageTestDTO dto = new ManageTestDTO();
//        }
//    }
}
