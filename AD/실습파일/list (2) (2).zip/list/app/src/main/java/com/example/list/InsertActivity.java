package com.example.list;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

class InsertActivity extends AppCompatActivity implements View.OnClickListener {
    EditText editTitle;
    EditText editWrite;
    EditText editContent;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bbs_insert);

        editTitle = (EditText)this.findViewById(R.id.editTitle);
        editWrite = (EditText)this.findViewById(R.id.editWriter);
        editContent = (EditText)this.findViewById(R.id.editContent);

        Button InsertBtn = (Button)this.findViewById(R.id.insertBtn);

        InsertBtn.setOnClickListener(this);

    }
    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.insertBtn:
                TestDTO dto = new TestDTO();
                dto.setTitle(editTitle.getText().toString());
                dto.setWriter(editWrite.getText().toString());
                dto.setContent(editContent.getText().toString());
                TestDAO dao = new TestDAO(this);
                int n = dao.insertRecord(dto);
                if(n > 0) {
                    Log.v("MYTAG", n + "번에 저장되었습니다.");
                }
                else{
                    Log.v("MYTAG","저장실패");
                    }
                finish();
                break;
                }
        }


    }

