
package com.example.list;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity{


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button WrtieBtn = (Button)this.findViewById(R.id.writeBtn);
        Button ListBtn = (Button)this.findViewById(R.id.listBtn);

        WrtieBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "액티비티를 이동합니다.", Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(), InsertActivity.class));
                finish();

            }
        });



        ListBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "액티비티를 이동합니다.", Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(), ListActivity.class));
                finish();
            }
        });
    }


}
