package org.techtown.myapplication;

import android.app.Activity;

import androidx.appcompat.app.AppCompatActivity;

public class SubActivity extends AppCompatActivity {

}
