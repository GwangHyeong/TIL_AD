package org.techtown.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //리스트
        String[] list = {"1", "2", "3", "4"};
        //리스트 클릭시 보여질 리스트.
        final String[] list_explain = {"000000000", "100000000", "22222", "333333"};
        for (int i = 0; i < list.length; i++) {
            Log.e("for", String.valueOf(i));
        }
        ArrayAdapter<String> adapter;
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1, list);
        ListView listview = (ListView) findViewById(R.id.ListView);
        listview.setAdapter(adapter);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.e("리스트뷰테스트", "listviewtest");
                Log.e("리스트뷰테스트", String.valueOf(position));

                Toast.makeText(getApplicationContext(), ((TextView) view).getText() + list_explain[position], Toast.LENGTH_LONG).show();

            }
        });
    }
}
